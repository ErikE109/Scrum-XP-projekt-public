﻿namespace Models
{
    public class Personal
    {
        public Personal()
        {

        }

        public int Id { get; set; }

        public string Name { get; set; }

        public string Lösenord { get; set; }
    }
}
