namespace View
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle8 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle9 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle10 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle7 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle11 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle13 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle14 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle15 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle12 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle16 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle18 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle19 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle20 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle17 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle21 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle23 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle24 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle25 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle22 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle26 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle28 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle29 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle30 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle27 = new DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            tabControl1=new TabControl();
            tabPage1=new TabPage();
            lblStartHeader=new Label();
            btnStartSkapa=new Button();
            dataGridStart=new DataGridView();
            Column1=new DataGridViewTextBoxColumn();
            Column2=new DataGridViewTextBoxColumn();
            Datum=new DataGridViewTextBoxColumn();
            Column5=new DataGridViewTextBoxColumn();
            Orderstatus=new DataGridViewTextBoxColumn();
            label6=new Label();
            tabPage2=new TabPage();
            label16=new Label();
            cbbOrderStatus=new ComboBox();
            label7=new Label();
            btnSökBeställning=new Button();
            tbxSökBeställning=new TextBox();
            btnBeställningÄndra=new Button();
            btnBeställningLäggtill=new Button();
            dataGridBeställning=new DataGridView();
            dataGridViewTextBoxColumn5=new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn6=new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn7=new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn8=new DataGridViewTextBoxColumn();
            Column4=new DataGridViewTextBoxColumn();
            tabPage3=new TabPage();
            label8=new Label();
            btnKundSök=new Button();
            tbxSökKund=new TextBox();
            btnKundÄndra=new Button();
            btnKundLäggtill=new Button();
            dataGridKund=new DataGridView();
            dataGridViewTextBoxColumn2=new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn1=new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn3=new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn4=new DataGridViewTextBoxColumn();
            Column3=new DataGridViewTextBoxColumn();
            tabPage4=new TabPage();
            label9=new Label();
            btnÄndraHatt=new Button();
            btnLäggTillHatt=new Button();
            dataGridHatt=new DataGridView();
            dataGridViewTextBoxColumn9=new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn10=new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn13=new DataGridViewTextBoxColumn();
            tabPage5=new TabPage();
            label11=new Label();
            label10=new Label();
            dataGridDekoration=new DataGridView();
            dataGridViewTextBoxColumn15=new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn16=new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn17=new DataGridViewTextBoxColumn();
            dataGridMaterial=new DataGridView();
            dataGridViewTextBoxColumn11=new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn12=new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn14=new DataGridViewTextBoxColumn();
            tabPage7=new TabPage();
            panel2=new Panel();
            label13=new Label();
            btnSökStatistik=new Button();
            dtpToDate=new DateTimePicker();
            label15=new Label();
            dtpFromDate=new DateTimePicker();
            label14=new Label();
            btnPersonalÄndra=new Button();
            btnPersonalRegistrera=new Button();
            btnStart=new Button();
            btnBeställningar=new Button();
            btnKunder=new Button();
            btnHattar=new Button();
            btnMaterial=new Button();
            button7=new Button();
            label1=new Label();
            label2=new Label();
            label3=new Label();
            label4=new Label();
            label5=new Label();
            panel1=new Panel();
            btnStatistik=new Button();
            label17=new Label();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridStart).BeginInit();
            tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridBeställning).BeginInit();
            tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridKund).BeginInit();
            tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridHatt).BeginInit();
            tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridDekoration).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridMaterial).BeginInit();
            tabPage7.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Controls.Add(tabPage3);
            tabControl1.Controls.Add(tabPage4);
            tabControl1.Controls.Add(tabPage5);
            tabControl1.Controls.Add(tabPage7);
            tabControl1.Location=new Point(243, 74);
            tabControl1.Name="tabControl1";
            tabControl1.SelectedIndex=0;
            tabControl1.Size=new Size(1056, 614);
            tabControl1.TabIndex=0;
            // 
            // tabPage1
            // 
            tabPage1.BackColor=Color.White;
            tabPage1.Controls.Add(lblStartHeader);
            tabPage1.Controls.Add(btnStartSkapa);
            tabPage1.Controls.Add(dataGridStart);
            tabPage1.Controls.Add(label6);
            tabPage1.Location=new Point(4, 29);
            tabPage1.Name="tabPage1";
            tabPage1.Padding=new Padding(3);
            tabPage1.Size=new Size(1048, 581);
            tabPage1.TabIndex=0;
            tabPage1.Text="tabPage1";
            // 
            // lblStartHeader
            // 
            lblStartHeader.AutoSize=true;
            lblStartHeader.Font=new Font("Bahnschrift", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            lblStartHeader.ForeColor=Color.Black;
            lblStartHeader.Location=new Point(27, 29);
            lblStartHeader.Name="lblStartHeader";
            lblStartHeader.Size=new Size(263, 28);
            lblStartHeader.TabIndex=18;
            lblStartHeader.Text="Senaste beställningarna";
            lblStartHeader.TextAlign=ContentAlignment.MiddleCenter;
            // 
            // btnStartSkapa
            // 
            btnStartSkapa.BackColor=Color.FromArgb(44, 44, 44);
            btnStartSkapa.FlatStyle=FlatStyle.Flat;
            btnStartSkapa.Font=new Font("Bahnschrift Light", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnStartSkapa.ForeColor=Color.White;
            btnStartSkapa.Location=new Point(51, 517);
            btnStartSkapa.Name="btnStartSkapa";
            btnStartSkapa.Size=new Size(274, 39);
            btnStartSkapa.TabIndex=17;
            btnStartSkapa.Text="Skapa ny beställning";
            btnStartSkapa.UseVisualStyleBackColor=false;
            btnStartSkapa.Click+=btnStartSkapa_Click;
            // 
            // dataGridStart
            // 
            dataGridStart.AllowUserToAddRows=false;
            dataGridStart.BackgroundColor=SystemColors.Window;
            dataGridStart.BorderStyle=BorderStyle.None;
            dataGridStart.ColumnHeadersBorderStyle=DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment=DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor=Color.FromArgb(44, 44, 44);
            dataGridViewCellStyle1.Font=new Font("Bahnschrift SemiBold", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor=Color.White;
            dataGridViewCellStyle1.SelectionBackColor=Color.FromArgb(44, 44, 44);
            dataGridViewCellStyle1.SelectionForeColor=SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode=DataGridViewTriState.True;
            dataGridStart.ColumnHeadersDefaultCellStyle=dataGridViewCellStyle1;
            dataGridStart.ColumnHeadersHeightSizeMode=DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridStart.Columns.AddRange(new DataGridViewColumn[] { Column1, Column2, Datum, Column5, Orderstatus });
            dataGridViewCellStyle3.Alignment=DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor=SystemColors.Window;
            dataGridViewCellStyle3.Font=new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle3.ForeColor=Color.White;
            dataGridViewCellStyle3.SelectionBackColor=Color.FromArgb(224, 224, 224);
            dataGridViewCellStyle3.SelectionForeColor=Color.Black;
            dataGridViewCellStyle3.WrapMode=DataGridViewTriState.False;
            dataGridStart.DefaultCellStyle=dataGridViewCellStyle3;
            dataGridStart.EnableHeadersVisualStyles=false;
            dataGridStart.GridColor=Color.FromArgb(224, 224, 224);
            dataGridStart.Location=new Point(51, 97);
            dataGridStart.MultiSelect=false;
            dataGridStart.Name="dataGridStart";
            dataGridStart.ReadOnly=true;
            dataGridViewCellStyle4.Alignment=DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor=SystemColors.Control;
            dataGridViewCellStyle4.Font=new Font("Bahnschrift", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle4.ForeColor=SystemColors.WindowText;
            dataGridViewCellStyle4.Padding=new Padding(3);
            dataGridViewCellStyle4.SelectionBackColor=SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor=SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode=DataGridViewTriState.True;
            dataGridStart.RowHeadersDefaultCellStyle=dataGridViewCellStyle4;
            dataGridStart.RowHeadersVisible=false;
            dataGridStart.RowHeadersWidth=51;
            dataGridViewCellStyle5.Font=new Font("Bahnschrift", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle5.Padding=new Padding(3);
            dataGridStart.RowsDefaultCellStyle=dataGridViewCellStyle5;
            dataGridStart.RowTemplate.Height=29;
            dataGridStart.SelectionMode=DataGridViewSelectionMode.FullRowSelect;
            dataGridStart.Size=new Size(940, 404);
            dataGridStart.TabIndex=3;
            // 
            // Column1
            // 
            Column1.AutoSizeMode=DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle2.Font=new Font("Microsoft Sans Serif", 7.8F, FontStyle.Bold, GraphicsUnit.Point);
            Column1.DefaultCellStyle=dataGridViewCellStyle2;
            Column1.HeaderText="Ordernummer";
            Column1.MinimumWidth=6;
            Column1.Name="Column1";
            Column1.ReadOnly=true;
            // 
            // Column2
            // 
            Column2.AutoSizeMode=DataGridViewAutoSizeColumnMode.Fill;
            Column2.HeaderText="Kund";
            Column2.MinimumWidth=6;
            Column2.Name="Column2";
            Column2.ReadOnly=true;
            // 
            // Datum
            // 
            Datum.AutoSizeMode=DataGridViewAutoSizeColumnMode.Fill;
            Datum.HeaderText="Datum";
            Datum.MinimumWidth=6;
            Datum.Name="Datum";
            Datum.ReadOnly=true;
            // 
            // Column5
            // 
            Column5.AutoSizeMode=DataGridViewAutoSizeColumnMode.Fill;
            Column5.HeaderText="Leveransadress";
            Column5.MinimumWidth=6;
            Column5.Name="Column5";
            Column5.ReadOnly=true;
            // 
            // Orderstatus
            // 
            Orderstatus.AutoSizeMode=DataGridViewAutoSizeColumnMode.Fill;
            Orderstatus.HeaderText="Orderstatus";
            Orderstatus.MinimumWidth=6;
            Orderstatus.Name="Orderstatus";
            Orderstatus.ReadOnly=true;
            // 
            // label6
            // 
            label6.AutoSize=true;
            label6.Location=new Point(329, 139);
            label6.Name="label6";
            label6.Size=new Size(0, 20);
            label6.TabIndex=0;
            // 
            // tabPage2
            // 
            tabPage2.BackColor=Color.White;
            tabPage2.Controls.Add(label16);
            tabPage2.Controls.Add(cbbOrderStatus);
            tabPage2.Controls.Add(label7);
            tabPage2.Controls.Add(btnSökBeställning);
            tabPage2.Controls.Add(tbxSökBeställning);
            tabPage2.Controls.Add(btnBeställningÄndra);
            tabPage2.Controls.Add(btnBeställningLäggtill);
            tabPage2.Controls.Add(dataGridBeställning);
            tabPage2.Location=new Point(4, 29);
            tabPage2.Name="tabPage2";
            tabPage2.Padding=new Padding(3);
            tabPage2.Size=new Size(1048, 581);
            tabPage2.TabIndex=1;
            tabPage2.Text="tabPage2";
            // 
            // label16
            // 
            label16.AutoSize=true;
            label16.Font=new Font("Bahnschrift Light", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label16.ForeColor=Color.Black;
            label16.Location=new Point(643, 10);
            label16.Name="label16";
            label16.Size=new Size(105, 21);
            label16.TabIndex=23;
            label16.Text="Orderstatus:";
            // 
            // cbbOrderStatus
            // 
            cbbOrderStatus.DropDownStyle=ComboBoxStyle.DropDownList;
            cbbOrderStatus.FormattingEnabled=true;
            cbbOrderStatus.Items.AddRange(new object[] { "--Alla--", "Ny beställning", "Förfrågan skickad", "Bekräftad", "Under tillverkning", "Skickad", "Betald" });
            cbbOrderStatus.Location=new Point(754, 7);
            cbbOrderStatus.Name="cbbOrderStatus";
            cbbOrderStatus.Size=new Size(237, 28);
            cbbOrderStatus.TabIndex=22;
            cbbOrderStatus.SelectedIndexChanged+=cbbOrderStatus_SelectedIndexChanged;
            // 
            // label7
            // 
            label7.AutoSize=true;
            label7.Font=new Font("Bahnschrift", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            label7.ForeColor=Color.Black;
            label7.Location=new Point(27, 29);
            label7.Name="label7";
            label7.Size=new Size(151, 28);
            label7.TabIndex=21;
            label7.Text="Beställningar";
            label7.TextAlign=ContentAlignment.MiddleCenter;
            // 
            // btnSökBeställning
            // 
            btnSökBeställning.BackColor=Color.FromArgb(44, 44, 44);
            btnSökBeställning.FlatStyle=FlatStyle.Flat;
            btnSökBeställning.Font=new Font("Bahnschrift Light", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnSökBeställning.ForeColor=Color.White;
            btnSökBeställning.Location=new Point(885, 57);
            btnSökBeställning.Name="btnSökBeställning";
            btnSökBeställning.Size=new Size(106, 35);
            btnSökBeställning.TabIndex=20;
            btnSökBeställning.Text="Sök";
            btnSökBeställning.UseVisualStyleBackColor=false;
            btnSökBeställning.Click+=btnSökBeställning_Click;
            // 
            // tbxSökBeställning
            // 
            tbxSökBeställning.BorderStyle=BorderStyle.FixedSingle;
            tbxSökBeställning.Location=new Point(413, 61);
            tbxSökBeställning.Name="tbxSökBeställning";
            tbxSökBeställning.PlaceholderText="Sök..";
            tbxSökBeställning.Size=new Size(466, 27);
            tbxSökBeställning.TabIndex=19;
            // 
            // btnBeställningÄndra
            // 
            btnBeställningÄndra.BackColor=Color.FromArgb(44, 44, 44);
            btnBeställningÄndra.FlatStyle=FlatStyle.Flat;
            btnBeställningÄndra.Font=new Font("Bahnschrift Light", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnBeställningÄndra.ForeColor=Color.White;
            btnBeställningÄndra.Location=new Point(838, 517);
            btnBeställningÄndra.Name="btnBeställningÄndra";
            btnBeställningÄndra.Size=new Size(153, 39);
            btnBeställningÄndra.TabIndex=18;
            btnBeställningÄndra.Text="Granska beställning";
            btnBeställningÄndra.UseVisualStyleBackColor=false;
            btnBeställningÄndra.Click+=btnBeställningÄndra_Click;
            // 
            // btnBeställningLäggtill
            // 
            btnBeställningLäggtill.BackColor=Color.FromArgb(44, 44, 44);
            btnBeställningLäggtill.FlatStyle=FlatStyle.Flat;
            btnBeställningLäggtill.Font=new Font("Bahnschrift Light", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnBeställningLäggtill.ForeColor=Color.White;
            btnBeställningLäggtill.Location=new Point(51, 517);
            btnBeställningLäggtill.Name="btnBeställningLäggtill";
            btnBeställningLäggtill.Size=new Size(145, 39);
            btnBeställningLäggtill.TabIndex=16;
            btnBeställningLäggtill.Text="Lägg till";
            btnBeställningLäggtill.UseVisualStyleBackColor=false;
            btnBeställningLäggtill.Click+=btnBeställningLäggtill_Click;
            // 
            // dataGridBeställning
            // 
            dataGridBeställning.AllowUserToAddRows=false;
            dataGridBeställning.BackgroundColor=Color.White;
            dataGridBeställning.BorderStyle=BorderStyle.None;
            dataGridBeställning.ColumnHeadersBorderStyle=DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle6.Alignment=DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor=Color.FromArgb(44, 44, 44);
            dataGridViewCellStyle6.Font=new Font("Bahnschrift SemiBold", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            dataGridViewCellStyle6.ForeColor=Color.White;
            dataGridViewCellStyle6.SelectionBackColor=Color.FromArgb(44, 44, 44);
            dataGridViewCellStyle6.SelectionForeColor=SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode=DataGridViewTriState.True;
            dataGridBeställning.ColumnHeadersDefaultCellStyle=dataGridViewCellStyle6;
            dataGridBeställning.ColumnHeadersHeightSizeMode=DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridBeställning.Columns.AddRange(new DataGridViewColumn[] { dataGridViewTextBoxColumn5, dataGridViewTextBoxColumn6, dataGridViewTextBoxColumn7, dataGridViewTextBoxColumn8, Column4 });
            dataGridViewCellStyle8.Alignment=DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor=SystemColors.Window;
            dataGridViewCellStyle8.Font=new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle8.ForeColor=Color.White;
            dataGridViewCellStyle8.SelectionBackColor=Color.FromArgb(210, 210, 210);
            dataGridViewCellStyle8.SelectionForeColor=Color.Black;
            dataGridViewCellStyle8.WrapMode=DataGridViewTriState.False;
            dataGridBeställning.DefaultCellStyle=dataGridViewCellStyle8;
            dataGridBeställning.EnableHeadersVisualStyles=false;
            dataGridBeställning.GridColor=Color.FromArgb(224, 224, 224);
            dataGridBeställning.Location=new Point(51, 97);
            dataGridBeställning.MultiSelect=false;
            dataGridBeställning.Name="dataGridBeställning";
            dataGridBeställning.ReadOnly=true;
            dataGridViewCellStyle9.Alignment=DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor=SystemColors.Control;
            dataGridViewCellStyle9.Font=new Font("Bahnschrift", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle9.ForeColor=SystemColors.WindowText;
            dataGridViewCellStyle9.Padding=new Padding(3);
            dataGridViewCellStyle9.SelectionBackColor=SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor=SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode=DataGridViewTriState.True;
            dataGridBeställning.RowHeadersDefaultCellStyle=dataGridViewCellStyle9;
            dataGridBeställning.RowHeadersVisible=false;
            dataGridBeställning.RowHeadersWidth=51;
            dataGridViewCellStyle10.Font=new Font("Bahnschrift", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle10.Padding=new Padding(3);
            dataGridBeställning.RowsDefaultCellStyle=dataGridViewCellStyle10;
            dataGridBeställning.RowTemplate.Height=29;
            dataGridBeställning.SelectionMode=DataGridViewSelectionMode.FullRowSelect;
            dataGridBeställning.Size=new Size(940, 404);
            dataGridBeställning.TabIndex=4;
            dataGridBeställning.SelectionChanged+=dataGridBeställning_SelectionChanged;
            // 
            // dataGridViewTextBoxColumn5
            // 
            dataGridViewTextBoxColumn5.AutoSizeMode=DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle7.Font=new Font("Microsoft Sans Serif", 7.8F, FontStyle.Bold, GraphicsUnit.Point);
            dataGridViewTextBoxColumn5.DefaultCellStyle=dataGridViewCellStyle7;
            dataGridViewTextBoxColumn5.HeaderText="Ordernummer";
            dataGridViewTextBoxColumn5.MinimumWidth=6;
            dataGridViewTextBoxColumn5.Name="dataGridViewTextBoxColumn5";
            dataGridViewTextBoxColumn5.ReadOnly=true;
            // 
            // dataGridViewTextBoxColumn6
            // 
            dataGridViewTextBoxColumn6.AutoSizeMode=DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewTextBoxColumn6.HeaderText="Kund";
            dataGridViewTextBoxColumn6.MinimumWidth=6;
            dataGridViewTextBoxColumn6.Name="dataGridViewTextBoxColumn6";
            dataGridViewTextBoxColumn6.ReadOnly=true;
            // 
            // dataGridViewTextBoxColumn7
            // 
            dataGridViewTextBoxColumn7.AutoSizeMode=DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewTextBoxColumn7.HeaderText="Datum";
            dataGridViewTextBoxColumn7.MinimumWidth=6;
            dataGridViewTextBoxColumn7.Name="dataGridViewTextBoxColumn7";
            dataGridViewTextBoxColumn7.ReadOnly=true;
            // 
            // dataGridViewTextBoxColumn8
            // 
            dataGridViewTextBoxColumn8.AutoSizeMode=DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewTextBoxColumn8.HeaderText="Leveransadress";
            dataGridViewTextBoxColumn8.MinimumWidth=6;
            dataGridViewTextBoxColumn8.Name="dataGridViewTextBoxColumn8";
            dataGridViewTextBoxColumn8.ReadOnly=true;
            // 
            // Column4
            // 
            Column4.AutoSizeMode=DataGridViewAutoSizeColumnMode.Fill;
            Column4.HeaderText="Orderstatus";
            Column4.MinimumWidth=6;
            Column4.Name="Column4";
            Column4.ReadOnly=true;
            // 
            // tabPage3
            // 
            tabPage3.BackColor=Color.White;
            tabPage3.Controls.Add(label8);
            tabPage3.Controls.Add(btnKundSök);
            tabPage3.Controls.Add(tbxSökKund);
            tabPage3.Controls.Add(btnKundÄndra);
            tabPage3.Controls.Add(btnKundLäggtill);
            tabPage3.Controls.Add(dataGridKund);
            tabPage3.Location=new Point(4, 29);
            tabPage3.Name="tabPage3";
            tabPage3.Padding=new Padding(3);
            tabPage3.Size=new Size(1048, 581);
            tabPage3.TabIndex=2;
            tabPage3.Text="tabPage3";
            // 
            // label8
            // 
            label8.AutoSize=true;
            label8.Font=new Font("Bahnschrift", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            label8.ForeColor=Color.Black;
            label8.Location=new Point(27, 29);
            label8.Name="label8";
            label8.Size=new Size(87, 28);
            label8.TabIndex=22;
            label8.Text="Kunder";
            label8.TextAlign=ContentAlignment.MiddleCenter;
            // 
            // btnKundSök
            // 
            btnKundSök.BackColor=Color.FromArgb(44, 44, 44);
            btnKundSök.FlatStyle=FlatStyle.Flat;
            btnKundSök.Font=new Font("Bahnschrift Light", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnKundSök.ForeColor=Color.White;
            btnKundSök.Location=new Point(885, 57);
            btnKundSök.Name="btnKundSök";
            btnKundSök.Size=new Size(106, 35);
            btnKundSök.TabIndex=17;
            btnKundSök.Text="Sök";
            btnKundSök.UseVisualStyleBackColor=false;
            // 
            // tbxSökKund
            // 
            tbxSökKund.BorderStyle=BorderStyle.FixedSingle;
            tbxSökKund.Location=new Point(413, 61);
            tbxSökKund.Name="tbxSökKund";
            tbxSökKund.PlaceholderText="Sök..";
            tbxSökKund.Size=new Size(466, 27);
            tbxSökKund.TabIndex=16;
            // 
            // btnKundÄndra
            // 
            btnKundÄndra.BackColor=Color.FromArgb(44, 44, 44);
            btnKundÄndra.FlatStyle=FlatStyle.Flat;
            btnKundÄndra.Font=new Font("Bahnschrift Light", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnKundÄndra.ForeColor=Color.White;
            btnKundÄndra.Location=new Point(846, 517);
            btnKundÄndra.Name="btnKundÄndra";
            btnKundÄndra.Size=new Size(145, 39);
            btnKundÄndra.TabIndex=15;
            btnKundÄndra.Text="Ändra";
            btnKundÄndra.UseVisualStyleBackColor=false;
            btnKundÄndra.Click+=btnKundÄndra_Click;
            // 
            // btnKundLäggtill
            // 
            btnKundLäggtill.BackColor=Color.FromArgb(44, 44, 44);
            btnKundLäggtill.FlatStyle=FlatStyle.Flat;
            btnKundLäggtill.Font=new Font("Bahnschrift Light", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnKundLäggtill.ForeColor=Color.White;
            btnKundLäggtill.Location=new Point(51, 517);
            btnKundLäggtill.Name="btnKundLäggtill";
            btnKundLäggtill.Size=new Size(145, 39);
            btnKundLäggtill.TabIndex=13;
            btnKundLäggtill.Text="Lägg till";
            btnKundLäggtill.UseVisualStyleBackColor=false;
            btnKundLäggtill.Click+=btnKundLäggtill_Click;
            // 
            // dataGridKund
            // 
            dataGridKund.AllowUserToAddRows=false;
            dataGridKund.BackgroundColor=Color.White;
            dataGridKund.BorderStyle=BorderStyle.None;
            dataGridKund.ColumnHeadersBorderStyle=DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle11.Alignment=DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor=Color.FromArgb(44, 44, 44);
            dataGridViewCellStyle11.Font=new Font("Bahnschrift SemiBold", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            dataGridViewCellStyle11.ForeColor=Color.White;
            dataGridViewCellStyle11.SelectionBackColor=Color.FromArgb(44, 44, 44);
            dataGridViewCellStyle11.SelectionForeColor=Color.FromArgb(224, 224, 224);
            dataGridViewCellStyle11.WrapMode=DataGridViewTriState.True;
            dataGridKund.ColumnHeadersDefaultCellStyle=dataGridViewCellStyle11;
            dataGridKund.ColumnHeadersHeightSizeMode=DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridKund.Columns.AddRange(new DataGridViewColumn[] { dataGridViewTextBoxColumn2, dataGridViewTextBoxColumn1, dataGridViewTextBoxColumn3, dataGridViewTextBoxColumn4, Column3 });
            dataGridViewCellStyle13.Alignment=DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor=SystemColors.Window;
            dataGridViewCellStyle13.Font=new Font("Bahnschrift Light", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle13.ForeColor=Color.White;
            dataGridViewCellStyle13.SelectionBackColor=Color.FromArgb(210, 210, 210);
            dataGridViewCellStyle13.SelectionForeColor=Color.Black;
            dataGridViewCellStyle13.WrapMode=DataGridViewTriState.False;
            dataGridKund.DefaultCellStyle=dataGridViewCellStyle13;
            dataGridKund.EnableHeadersVisualStyles=false;
            dataGridKund.GridColor=Color.LightGray;
            dataGridKund.Location=new Point(51, 97);
            dataGridKund.MultiSelect=false;
            dataGridKund.Name="dataGridKund";
            dataGridKund.ReadOnly=true;
            dataGridViewCellStyle14.Alignment=DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor=SystemColors.Control;
            dataGridViewCellStyle14.Font=new Font("Bahnschrift", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle14.ForeColor=SystemColors.WindowText;
            dataGridViewCellStyle14.Padding=new Padding(3);
            dataGridViewCellStyle14.SelectionBackColor=SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor=SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode=DataGridViewTriState.True;
            dataGridKund.RowHeadersDefaultCellStyle=dataGridViewCellStyle14;
            dataGridKund.RowHeadersVisible=false;
            dataGridKund.RowHeadersWidth=51;
            dataGridViewCellStyle15.Font=new Font("Bahnschrift", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle15.Padding=new Padding(3);
            dataGridKund.RowsDefaultCellStyle=dataGridViewCellStyle15;
            dataGridKund.RowTemplate.Height=29;
            dataGridKund.SelectionMode=DataGridViewSelectionMode.FullRowSelect;
            dataGridKund.Size=new Size(940, 414);
            dataGridKund.TabIndex=4;
            // 
            // dataGridViewTextBoxColumn2
            // 
            dataGridViewTextBoxColumn2.AutoSizeMode=DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewTextBoxColumn2.HeaderText="KundID";
            dataGridViewTextBoxColumn2.MinimumWidth=6;
            dataGridViewTextBoxColumn2.Name="dataGridViewTextBoxColumn2";
            dataGridViewTextBoxColumn2.ReadOnly=true;
            // 
            // dataGridViewTextBoxColumn1
            // 
            dataGridViewTextBoxColumn1.AutoSizeMode=DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle12.Font=new Font("Microsoft Sans Serif", 7.8F, FontStyle.Bold, GraphicsUnit.Point);
            dataGridViewTextBoxColumn1.DefaultCellStyle=dataGridViewCellStyle12;
            dataGridViewTextBoxColumn1.HeaderText="Namn";
            dataGridViewTextBoxColumn1.MinimumWidth=6;
            dataGridViewTextBoxColumn1.Name="dataGridViewTextBoxColumn1";
            dataGridViewTextBoxColumn1.ReadOnly=true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            dataGridViewTextBoxColumn3.AutoSizeMode=DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewTextBoxColumn3.HeaderText="Adress";
            dataGridViewTextBoxColumn3.MinimumWidth=6;
            dataGridViewTextBoxColumn3.Name="dataGridViewTextBoxColumn3";
            dataGridViewTextBoxColumn3.ReadOnly=true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            dataGridViewTextBoxColumn4.AutoSizeMode=DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewTextBoxColumn4.HeaderText="Telefon";
            dataGridViewTextBoxColumn4.MinimumWidth=6;
            dataGridViewTextBoxColumn4.Name="dataGridViewTextBoxColumn4";
            dataGridViewTextBoxColumn4.ReadOnly=true;
            // 
            // Column3
            // 
            Column3.AutoSizeMode=DataGridViewAutoSizeColumnMode.Fill;
            Column3.HeaderText="Epost";
            Column3.MinimumWidth=6;
            Column3.Name="Column3";
            Column3.ReadOnly=true;
            // 
            // tabPage4
            // 
            tabPage4.BackColor=Color.White;
            tabPage4.Controls.Add(label9);
            tabPage4.Controls.Add(btnÄndraHatt);
            tabPage4.Controls.Add(btnLäggTillHatt);
            tabPage4.Controls.Add(dataGridHatt);
            tabPage4.Location=new Point(4, 29);
            tabPage4.Name="tabPage4";
            tabPage4.Padding=new Padding(3);
            tabPage4.Size=new Size(1048, 581);
            tabPage4.TabIndex=3;
            tabPage4.Text="tabPage4";
            // 
            // label9
            // 
            label9.AutoSize=true;
            label9.Font=new Font("Bahnschrift", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            label9.ForeColor=Color.Black;
            label9.Location=new Point(27, 29);
            label9.Name="label9";
            label9.Size=new Size(78, 28);
            label9.TabIndex=23;
            label9.Text="Hattar";
            label9.TextAlign=ContentAlignment.MiddleCenter;
            // 
            // btnÄndraHatt
            // 
            btnÄndraHatt.BackColor=Color.FromArgb(44, 44, 44);
            btnÄndraHatt.FlatStyle=FlatStyle.Flat;
            btnÄndraHatt.Font=new Font("Bahnschrift Light", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnÄndraHatt.ForeColor=Color.White;
            btnÄndraHatt.Location=new Point(846, 517);
            btnÄndraHatt.Name="btnÄndraHatt";
            btnÄndraHatt.Size=new Size(145, 39);
            btnÄndraHatt.TabIndex=16;
            btnÄndraHatt.Text="Ändra";
            btnÄndraHatt.UseVisualStyleBackColor=false;
            btnÄndraHatt.Click+=btnändraHatt_Click;
            // 
            // btnLäggTillHatt
            // 
            btnLäggTillHatt.BackColor=Color.FromArgb(44, 44, 44);
            btnLäggTillHatt.FlatStyle=FlatStyle.Flat;
            btnLäggTillHatt.Font=new Font("Bahnschrift Light", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnLäggTillHatt.ForeColor=Color.White;
            btnLäggTillHatt.Location=new Point(51, 517);
            btnLäggTillHatt.Name="btnLäggTillHatt";
            btnLäggTillHatt.Size=new Size(145, 39);
            btnLäggTillHatt.TabIndex=14;
            btnLäggTillHatt.Text="Lägg till";
            btnLäggTillHatt.UseVisualStyleBackColor=false;
            btnLäggTillHatt.Click+=btnLäggTillHatt_Click;
            // 
            // dataGridHatt
            // 
            dataGridHatt.AllowUserToAddRows=false;
            dataGridHatt.BackgroundColor=Color.White;
            dataGridHatt.BorderStyle=BorderStyle.None;
            dataGridHatt.ColumnHeadersBorderStyle=DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle16.Alignment=DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor=Color.FromArgb(44, 44, 44);
            dataGridViewCellStyle16.Font=new Font("Bahnschrift SemiBold", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            dataGridViewCellStyle16.ForeColor=Color.White;
            dataGridViewCellStyle16.SelectionBackColor=Color.FromArgb(44, 44, 44);
            dataGridViewCellStyle16.SelectionForeColor=SystemColors.HighlightText;
            dataGridViewCellStyle16.WrapMode=DataGridViewTriState.True;
            dataGridHatt.ColumnHeadersDefaultCellStyle=dataGridViewCellStyle16;
            dataGridHatt.ColumnHeadersHeightSizeMode=DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridHatt.Columns.AddRange(new DataGridViewColumn[] { dataGridViewTextBoxColumn9, dataGridViewTextBoxColumn10, dataGridViewTextBoxColumn13 });
            dataGridViewCellStyle18.Alignment=DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor=SystemColors.Window;
            dataGridViewCellStyle18.Font=new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle18.ForeColor=Color.White;
            dataGridViewCellStyle18.SelectionBackColor=Color.FromArgb(210, 210, 210);
            dataGridViewCellStyle18.SelectionForeColor=Color.Black;
            dataGridViewCellStyle18.WrapMode=DataGridViewTriState.False;
            dataGridHatt.DefaultCellStyle=dataGridViewCellStyle18;
            dataGridHatt.EnableHeadersVisualStyles=false;
            dataGridHatt.GridColor=Color.LightGray;
            dataGridHatt.Location=new Point(51, 97);
            dataGridHatt.MultiSelect=false;
            dataGridHatt.Name="dataGridHatt";
            dataGridHatt.ReadOnly=true;
            dataGridViewCellStyle19.Alignment=DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle19.BackColor=SystemColors.Control;
            dataGridViewCellStyle19.Font=new Font("Bahnschrift", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle19.ForeColor=SystemColors.WindowText;
            dataGridViewCellStyle19.Padding=new Padding(3);
            dataGridViewCellStyle19.SelectionBackColor=SystemColors.Highlight;
            dataGridViewCellStyle19.SelectionForeColor=SystemColors.HighlightText;
            dataGridViewCellStyle19.WrapMode=DataGridViewTriState.True;
            dataGridHatt.RowHeadersDefaultCellStyle=dataGridViewCellStyle19;
            dataGridHatt.RowHeadersVisible=false;
            dataGridHatt.RowHeadersWidth=51;
            dataGridViewCellStyle20.Font=new Font("Bahnschrift", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle20.Padding=new Padding(3);
            dataGridHatt.RowsDefaultCellStyle=dataGridViewCellStyle20;
            dataGridHatt.RowTemplate.Height=29;
            dataGridHatt.SelectionMode=DataGridViewSelectionMode.FullRowSelect;
            dataGridHatt.Size=new Size(940, 403);
            dataGridHatt.TabIndex=5;
            // 
            // dataGridViewTextBoxColumn9
            // 
            dataGridViewTextBoxColumn9.AutoSizeMode=DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewTextBoxColumn9.HeaderText="HattID";
            dataGridViewTextBoxColumn9.MinimumWidth=6;
            dataGridViewTextBoxColumn9.Name="dataGridViewTextBoxColumn9";
            dataGridViewTextBoxColumn9.ReadOnly=true;
            // 
            // dataGridViewTextBoxColumn10
            // 
            dataGridViewTextBoxColumn10.AutoSizeMode=DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle17.Font=new Font("Microsoft Sans Serif", 7.8F, FontStyle.Bold, GraphicsUnit.Point);
            dataGridViewTextBoxColumn10.DefaultCellStyle=dataGridViewCellStyle17;
            dataGridViewTextBoxColumn10.HeaderText="Namn";
            dataGridViewTextBoxColumn10.MinimumWidth=6;
            dataGridViewTextBoxColumn10.Name="dataGridViewTextBoxColumn10";
            dataGridViewTextBoxColumn10.ReadOnly=true;
            // 
            // dataGridViewTextBoxColumn13
            // 
            dataGridViewTextBoxColumn13.AutoSizeMode=DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewTextBoxColumn13.HeaderText="Pris";
            dataGridViewTextBoxColumn13.MinimumWidth=6;
            dataGridViewTextBoxColumn13.Name="dataGridViewTextBoxColumn13";
            dataGridViewTextBoxColumn13.ReadOnly=true;
            // 
            // tabPage5
            // 
            tabPage5.BackColor=Color.White;
            tabPage5.Controls.Add(label11);
            tabPage5.Controls.Add(label10);
            tabPage5.Controls.Add(dataGridDekoration);
            tabPage5.Controls.Add(dataGridMaterial);
            tabPage5.Location=new Point(4, 29);
            tabPage5.Name="tabPage5";
            tabPage5.Padding=new Padding(3);
            tabPage5.Size=new Size(1048, 581);
            tabPage5.TabIndex=4;
            tabPage5.Text="tabPage5";
            // 
            // label11
            // 
            label11.AutoSize=true;
            label11.Font=new Font("Bahnschrift Light", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            label11.ForeColor=Color.Black;
            label11.Location=new Point(27, 303);
            label11.Name="label11";
            label11.Size=new Size(126, 28);
            label11.TabIndex=25;
            label11.Text="Dekoration";
            label11.TextAlign=ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            label10.AutoSize=true;
            label10.Font=new Font("Bahnschrift Light", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            label10.ForeColor=Color.Black;
            label10.Location=new Point(27, 29);
            label10.Name="label10";
            label10.Size=new Size(97, 28);
            label10.TabIndex=24;
            label10.Text="Material";
            label10.TextAlign=ContentAlignment.MiddleCenter;
            // 
            // dataGridDekoration
            // 
            dataGridDekoration.AllowUserToAddRows=false;
            dataGridDekoration.BackgroundColor=Color.White;
            dataGridDekoration.BorderStyle=BorderStyle.None;
            dataGridDekoration.ColumnHeadersBorderStyle=DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle21.Alignment=DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle21.BackColor=Color.FromArgb(44, 44, 44);
            dataGridViewCellStyle21.Font=new Font("Bahnschrift SemiBold", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            dataGridViewCellStyle21.ForeColor=Color.White;
            dataGridViewCellStyle21.SelectionBackColor=Color.FromArgb(44, 44, 44);
            dataGridViewCellStyle21.SelectionForeColor=SystemColors.HighlightText;
            dataGridViewCellStyle21.WrapMode=DataGridViewTriState.True;
            dataGridDekoration.ColumnHeadersDefaultCellStyle=dataGridViewCellStyle21;
            dataGridDekoration.ColumnHeadersHeightSizeMode=DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridDekoration.Columns.AddRange(new DataGridViewColumn[] { dataGridViewTextBoxColumn15, dataGridViewTextBoxColumn16, dataGridViewTextBoxColumn17 });
            dataGridViewCellStyle23.Alignment=DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle23.BackColor=SystemColors.Window;
            dataGridViewCellStyle23.Font=new Font("Bahnschrift Light", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle23.ForeColor=Color.White;
            dataGridViewCellStyle23.SelectionBackColor=Color.FromArgb(210, 210, 210);
            dataGridViewCellStyle23.SelectionForeColor=Color.Black;
            dataGridViewCellStyle23.WrapMode=DataGridViewTriState.False;
            dataGridDekoration.DefaultCellStyle=dataGridViewCellStyle23;
            dataGridDekoration.EnableHeadersVisualStyles=false;
            dataGridDekoration.GridColor=Color.FromArgb(224, 224, 224);
            dataGridDekoration.Location=new Point(69, 336);
            dataGridDekoration.MultiSelect=false;
            dataGridDekoration.Name="dataGridDekoration";
            dataGridDekoration.ReadOnly=true;
            dataGridViewCellStyle24.Alignment=DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle24.BackColor=SystemColors.Control;
            dataGridViewCellStyle24.Font=new Font("Bahnschrift", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle24.ForeColor=SystemColors.WindowText;
            dataGridViewCellStyle24.Padding=new Padding(3);
            dataGridViewCellStyle24.SelectionBackColor=SystemColors.Highlight;
            dataGridViewCellStyle24.SelectionForeColor=SystemColors.HighlightText;
            dataGridViewCellStyle24.WrapMode=DataGridViewTriState.True;
            dataGridDekoration.RowHeadersDefaultCellStyle=dataGridViewCellStyle24;
            dataGridDekoration.RowHeadersVisible=false;
            dataGridDekoration.RowHeadersWidth=51;
            dataGridViewCellStyle25.Font=new Font("Bahnschrift", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle25.Padding=new Padding(3);
            dataGridDekoration.RowsDefaultCellStyle=dataGridViewCellStyle25;
            dataGridDekoration.RowTemplate.Height=29;
            dataGridDekoration.SelectionMode=DataGridViewSelectionMode.FullRowSelect;
            dataGridDekoration.Size=new Size(864, 212);
            dataGridDekoration.TabIndex=19;
            // 
            // dataGridViewTextBoxColumn15
            // 
            dataGridViewTextBoxColumn15.AutoSizeMode=DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewTextBoxColumn15.HeaderText="DekorationsID";
            dataGridViewTextBoxColumn15.MinimumWidth=6;
            dataGridViewTextBoxColumn15.Name="dataGridViewTextBoxColumn15";
            dataGridViewTextBoxColumn15.ReadOnly=true;
            // 
            // dataGridViewTextBoxColumn16
            // 
            dataGridViewTextBoxColumn16.AutoSizeMode=DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle22.Font=new Font("Microsoft Sans Serif", 7.8F, FontStyle.Bold, GraphicsUnit.Point);
            dataGridViewTextBoxColumn16.DefaultCellStyle=dataGridViewCellStyle22;
            dataGridViewTextBoxColumn16.HeaderText="Typ";
            dataGridViewTextBoxColumn16.MinimumWidth=6;
            dataGridViewTextBoxColumn16.Name="dataGridViewTextBoxColumn16";
            dataGridViewTextBoxColumn16.ReadOnly=true;
            // 
            // dataGridViewTextBoxColumn17
            // 
            dataGridViewTextBoxColumn17.AutoSizeMode=DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewTextBoxColumn17.HeaderText="Styckpris";
            dataGridViewTextBoxColumn17.MinimumWidth=6;
            dataGridViewTextBoxColumn17.Name="dataGridViewTextBoxColumn17";
            dataGridViewTextBoxColumn17.ReadOnly=true;
            // 
            // dataGridMaterial
            // 
            dataGridMaterial.AllowUserToAddRows=false;
            dataGridMaterial.BackgroundColor=Color.White;
            dataGridMaterial.BorderStyle=BorderStyle.None;
            dataGridMaterial.ColumnHeadersBorderStyle=DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle26.Alignment=DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle26.BackColor=Color.FromArgb(44, 44, 44);
            dataGridViewCellStyle26.Font=new Font("Bahnschrift SemiBold", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            dataGridViewCellStyle26.ForeColor=Color.White;
            dataGridViewCellStyle26.SelectionBackColor=Color.FromArgb(44, 44, 44);
            dataGridViewCellStyle26.SelectionForeColor=Color.White;
            dataGridViewCellStyle26.WrapMode=DataGridViewTriState.True;
            dataGridMaterial.ColumnHeadersDefaultCellStyle=dataGridViewCellStyle26;
            dataGridMaterial.ColumnHeadersHeightSizeMode=DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridMaterial.Columns.AddRange(new DataGridViewColumn[] { dataGridViewTextBoxColumn11, dataGridViewTextBoxColumn12, dataGridViewTextBoxColumn14 });
            dataGridViewCellStyle28.Alignment=DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle28.BackColor=SystemColors.Window;
            dataGridViewCellStyle28.Font=new Font("Bahnschrift Light", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle28.ForeColor=Color.White;
            dataGridViewCellStyle28.SelectionBackColor=Color.FromArgb(210, 210, 210);
            dataGridViewCellStyle28.SelectionForeColor=Color.Black;
            dataGridViewCellStyle28.WrapMode=DataGridViewTriState.False;
            dataGridMaterial.DefaultCellStyle=dataGridViewCellStyle28;
            dataGridMaterial.EnableHeadersVisualStyles=false;
            dataGridMaterial.GridColor=Color.FromArgb(224, 224, 224);
            dataGridMaterial.Location=new Point(69, 63);
            dataGridMaterial.MultiSelect=false;
            dataGridMaterial.Name="dataGridMaterial";
            dataGridMaterial.ReadOnly=true;
            dataGridViewCellStyle29.Alignment=DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle29.BackColor=SystemColors.Control;
            dataGridViewCellStyle29.Font=new Font("Bahnschrift", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle29.ForeColor=SystemColors.WindowText;
            dataGridViewCellStyle29.Padding=new Padding(3);
            dataGridViewCellStyle29.SelectionBackColor=SystemColors.Highlight;
            dataGridViewCellStyle29.SelectionForeColor=SystemColors.HighlightText;
            dataGridViewCellStyle29.WrapMode=DataGridViewTriState.True;
            dataGridMaterial.RowHeadersDefaultCellStyle=dataGridViewCellStyle29;
            dataGridMaterial.RowHeadersVisible=false;
            dataGridMaterial.RowHeadersWidth=51;
            dataGridViewCellStyle30.Font=new Font("Bahnschrift", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle30.Padding=new Padding(3);
            dataGridMaterial.RowsDefaultCellStyle=dataGridViewCellStyle30;
            dataGridMaterial.RowTemplate.Height=29;
            dataGridMaterial.SelectionMode=DataGridViewSelectionMode.FullRowSelect;
            dataGridMaterial.Size=new Size(864, 217);
            dataGridMaterial.TabIndex=6;
            // 
            // dataGridViewTextBoxColumn11
            // 
            dataGridViewTextBoxColumn11.AutoSizeMode=DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewTextBoxColumn11.HeaderText="MaterialID";
            dataGridViewTextBoxColumn11.MinimumWidth=6;
            dataGridViewTextBoxColumn11.Name="dataGridViewTextBoxColumn11";
            dataGridViewTextBoxColumn11.ReadOnly=true;
            // 
            // dataGridViewTextBoxColumn12
            // 
            dataGridViewTextBoxColumn12.AutoSizeMode=DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle27.Font=new Font("Microsoft Sans Serif", 7.8F, FontStyle.Bold, GraphicsUnit.Point);
            dataGridViewTextBoxColumn12.DefaultCellStyle=dataGridViewCellStyle27;
            dataGridViewTextBoxColumn12.HeaderText="Typ";
            dataGridViewTextBoxColumn12.MinimumWidth=6;
            dataGridViewTextBoxColumn12.Name="dataGridViewTextBoxColumn12";
            dataGridViewTextBoxColumn12.ReadOnly=true;
            // 
            // dataGridViewTextBoxColumn14
            // 
            dataGridViewTextBoxColumn14.AutoSizeMode=DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewTextBoxColumn14.HeaderText="Meterpris";
            dataGridViewTextBoxColumn14.MinimumWidth=6;
            dataGridViewTextBoxColumn14.Name="dataGridViewTextBoxColumn14";
            dataGridViewTextBoxColumn14.ReadOnly=true;
            // 
            // tabPage7
            // 
            tabPage7.BackColor=Color.White;
            tabPage7.Controls.Add(panel2);
            tabPage7.Location=new Point(4, 29);
            tabPage7.Name="tabPage7";
            tabPage7.Padding=new Padding(3);
            tabPage7.Size=new Size(1048, 581);
            tabPage7.TabIndex=6;
            tabPage7.Text="tabPage7";
            // 
            // panel2
            // 
            panel2.BackColor=Color.WhiteSmoke;
            panel2.Controls.Add(label13);
            panel2.Controls.Add(btnSökStatistik);
            panel2.Controls.Add(dtpToDate);
            panel2.Controls.Add(label15);
            panel2.Controls.Add(dtpFromDate);
            panel2.Controls.Add(label14);
            panel2.Location=new Point(0, 0);
            panel2.Name="panel2";
            panel2.Size=new Size(1078, 163);
            panel2.TabIndex=28;
            // 
            // label13
            // 
            label13.AutoSize=true;
            label13.Font=new Font("Bahnschrift Light", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            label13.ForeColor=Color.Black;
            label13.Location=new Point(3, 6);
            label13.Name="label13";
            label13.Size=new Size(98, 28);
            label13.TabIndex=25;
            label13.Text="Statistik";
            label13.TextAlign=ContentAlignment.MiddleCenter;
            // 
            // btnSökStatistik
            // 
            btnSökStatistik.BackColor=Color.FromArgb(44, 44, 44);
            btnSökStatistik.FlatStyle=FlatStyle.Flat;
            btnSökStatistik.Font=new Font("Bahnschrift Light", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnSökStatistik.ForeColor=Color.White;
            btnSökStatistik.Location=new Point(752, 82);
            btnSökStatistik.Name="btnSökStatistik";
            btnSökStatistik.Size=new Size(155, 36);
            btnSökStatistik.TabIndex=16;
            btnSökStatistik.Text="Hämta Statistik";
            btnSökStatistik.UseVisualStyleBackColor=false;
            btnSökStatistik.Click+=btnHittaStatistik;
            // 
            // dtpToDate
            // 
            dtpToDate.Location=new Point(429, 85);
            dtpToDate.Name="dtpToDate";
            dtpToDate.Size=new Size(247, 27);
            dtpToDate.TabIndex=1;
            // 
            // label15
            // 
            label15.AutoSize=true;
            label15.Font=new Font("Bahnschrift Light", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label15.ForeColor=Color.Black;
            label15.Location=new Point(429, 53);
            label15.Name="label15";
            label15.Size=new Size(126, 24);
            label15.TabIndex=27;
            label15.Text="T.o.m. Datum";
            label15.TextAlign=ContentAlignment.MiddleCenter;
            // 
            // dtpFromDate
            // 
            dtpFromDate.Location=new Point(83, 85);
            dtpFromDate.Name="dtpFromDate";
            dtpFromDate.Size=new Size(247, 27);
            dtpFromDate.TabIndex=0;
            // 
            // label14
            // 
            label14.AutoSize=true;
            label14.Font=new Font("Bahnschrift Light", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label14.ForeColor=Color.Black;
            label14.Location=new Point(83, 54);
            label14.Name="label14";
            label14.Size=new Size(131, 24);
            label14.TabIndex=26;
            label14.Text="Fr.om. Datum";
            label14.TextAlign=ContentAlignment.MiddleCenter;
            // 
            // btnPersonalÄndra
            // 
            btnPersonalÄndra.BackColor=Color.FromArgb(44, 44, 44);
            btnPersonalÄndra.FlatStyle=FlatStyle.Flat;
            btnPersonalÄndra.Font=new Font("Bahnschrift Light", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnPersonalÄndra.ForeColor=Color.White;
            btnPersonalÄndra.Location=new Point(12, 578);
            btnPersonalÄndra.Name="btnPersonalÄndra";
            btnPersonalÄndra.Size=new Size(197, 40);
            btnPersonalÄndra.TabIndex=22;
            btnPersonalÄndra.Text="Ändra lösenord";
            btnPersonalÄndra.UseVisualStyleBackColor=false;
            btnPersonalÄndra.Click+=btnPersonalÄndra_Click;
            // 
            // btnPersonalRegistrera
            // 
            btnPersonalRegistrera.BackColor=Color.FromArgb(44, 44, 44);
            btnPersonalRegistrera.FlatStyle=FlatStyle.Flat;
            btnPersonalRegistrera.Font=new Font("Bahnschrift Light", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnPersonalRegistrera.ForeColor=Color.White;
            btnPersonalRegistrera.Location=new Point(12, 632);
            btnPersonalRegistrera.Name="btnPersonalRegistrera";
            btnPersonalRegistrera.Size=new Size(197, 39);
            btnPersonalRegistrera.TabIndex=21;
            btnPersonalRegistrera.Text="Registrera personal";
            btnPersonalRegistrera.UseVisualStyleBackColor=false;
            btnPersonalRegistrera.Click+=btnPersonalRegistrera_Click;
            // 
            // btnStart
            // 
            btnStart.FlatAppearance.BorderSize=0;
            btnStart.FlatStyle=FlatStyle.Flat;
            btnStart.Font=new Font("Bahnschrift Light", 12F, FontStyle.Regular, GraphicsUnit.Point);
            btnStart.ForeColor=Color.Black;
            btnStart.Location=new Point(20, 153);
            btnStart.Margin=new Padding(0, 0, 0, 20);
            btnStart.Name="btnStart";
            btnStart.Size=new Size(150, 29);
            btnStart.TabIndex=2;
            btnStart.Text="Start";
            btnStart.TextAlign=ContentAlignment.MiddleLeft;
            btnStart.UseVisualStyleBackColor=true;
            btnStart.Click+=btnStart_Click;
            // 
            // btnBeställningar
            // 
            btnBeställningar.FlatAppearance.BorderSize=0;
            btnBeställningar.FlatStyle=FlatStyle.Flat;
            btnBeställningar.Font=new Font("Bahnschrift Light", 12F, FontStyle.Regular, GraphicsUnit.Point);
            btnBeställningar.ForeColor=Color.Black;
            btnBeställningar.Location=new Point(16, 202);
            btnBeställningar.Margin=new Padding(0, 0, 0, 20);
            btnBeställningar.Name="btnBeställningar";
            btnBeställningar.Size=new Size(167, 37);
            btnBeställningar.TabIndex=3;
            btnBeställningar.Text="Beställningar";
            btnBeställningar.TextAlign=ContentAlignment.MiddleLeft;
            btnBeställningar.UseVisualStyleBackColor=true;
            btnBeställningar.Click+=btnBeställningar_Click;
            // 
            // btnKunder
            // 
            btnKunder.FlatAppearance.BorderSize=0;
            btnKunder.FlatStyle=FlatStyle.Flat;
            btnKunder.Font=new Font("Bahnschrift Light", 12F, FontStyle.Regular, GraphicsUnit.Point);
            btnKunder.ForeColor=Color.Black;
            btnKunder.Location=new Point(16, 252);
            btnKunder.Margin=new Padding(0, 0, 0, 20);
            btnKunder.Name="btnKunder";
            btnKunder.Size=new Size(150, 31);
            btnKunder.TabIndex=4;
            btnKunder.Text="Kunder";
            btnKunder.TextAlign=ContentAlignment.MiddleLeft;
            btnKunder.UseVisualStyleBackColor=true;
            btnKunder.Click+=btnKunder_Click;
            // 
            // btnHattar
            // 
            btnHattar.FlatAppearance.BorderSize=0;
            btnHattar.FlatStyle=FlatStyle.Flat;
            btnHattar.Font=new Font("Bahnschrift Light", 12F, FontStyle.Regular, GraphicsUnit.Point);
            btnHattar.ForeColor=Color.Black;
            btnHattar.Location=new Point(16, 302);
            btnHattar.Margin=new Padding(0, 0, 0, 20);
            btnHattar.Name="btnHattar";
            btnHattar.Size=new Size(150, 33);
            btnHattar.TabIndex=5;
            btnHattar.Text="Hattar";
            btnHattar.TextAlign=ContentAlignment.MiddleLeft;
            btnHattar.UseVisualStyleBackColor=true;
            btnHattar.Click+=btnHattar_Click;
            // 
            // btnMaterial
            // 
            btnMaterial.FlatAppearance.BorderSize=0;
            btnMaterial.FlatStyle=FlatStyle.Flat;
            btnMaterial.Font=new Font("Bahnschrift Light", 12F, FontStyle.Regular, GraphicsUnit.Point);
            btnMaterial.ForeColor=Color.Black;
            btnMaterial.Location=new Point(16, 356);
            btnMaterial.Margin=new Padding(0, 0, 0, 20);
            btnMaterial.Name="btnMaterial";
            btnMaterial.Size=new Size(149, 40);
            btnMaterial.TabIndex=6;
            btnMaterial.Text="Material";
            btnMaterial.TextAlign=ContentAlignment.MiddleLeft;
            btnMaterial.UseVisualStyleBackColor=true;
            btnMaterial.Click+=btnMaterial_Click;
            // 
            // button7
            // 
            button7.BackColor=Color.FromArgb(44, 44, 44);
            button7.FlatStyle=FlatStyle.Flat;
            button7.Font=new Font("Bahnschrift Light", 9F, FontStyle.Regular, GraphicsUnit.Point);
            button7.ForeColor=Color.White;
            button7.Location=new Point(1169, 39);
            button7.Name="button7";
            button7.Size=new Size(130, 29);
            button7.TabIndex=8;
            button7.Text="Logga ut";
            button7.UseVisualStyleBackColor=false;
            button7.Click+=btnLoggaUt_Click;
            // 
            // label1
            // 
            label1.BackColor=Color.Transparent;
            label1.ForeColor=Color.DarkGray;
            label1.Location=new Point(16, 182);
            label1.Margin=new Padding(0, 0, 0, 20);
            label1.Name="label1";
            label1.Size=new Size(167, 20);
            label1.TabIndex=0;
            label1.Text="_________________________";
            // 
            // label2
            // 
            label2.BackColor=Color.Transparent;
            label2.ForeColor=Color.DarkGray;
            label2.Location=new Point(16, 234);
            label2.Margin=new Padding(0, 0, 0, 20);
            label2.Name="label2";
            label2.Size=new Size(167, 19);
            label2.TabIndex=9;
            label2.Text="_________________________";
            // 
            // label3
            // 
            label3.BackColor=Color.Transparent;
            label3.ForeColor=Color.DarkGray;
            label3.Location=new Point(16, 284);
            label3.Margin=new Padding(0, 0, 0, 20);
            label3.Name="label3";
            label3.Size=new Size(167, 20);
            label3.TabIndex=10;
            label3.Text="_________________________";
            // 
            // label4
            // 
            label4.BackColor=Color.Transparent;
            label4.ForeColor=Color.DarkGray;
            label4.Location=new Point(16, 336);
            label4.Margin=new Padding(0, 0, 0, 20);
            label4.Name="label4";
            label4.Size=new Size(167, 20);
            label4.TabIndex=11;
            label4.Text="_________________________";
            // 
            // label5
            // 
            label5.BackColor=Color.Transparent;
            label5.ForeColor=Color.DarkGray;
            label5.Location=new Point(16, 390);
            label5.Margin=new Padding(0, 0, 0, 20);
            label5.Name="label5";
            label5.Size=new Size(167, 20);
            label5.TabIndex=12;
            label5.Text="_________________________";
            // 
            // panel1
            // 
            panel1.Location=new Point(243, 71);
            panel1.Margin=new Padding(3, 4, 3, 4);
            panel1.Name="panel1";
            panel1.Size=new Size(522, 29);
            panel1.TabIndex=13;
            // 
            // btnStatistik
            // 
            btnStatistik.FlatAppearance.BorderSize=0;
            btnStatistik.FlatStyle=FlatStyle.Flat;
            btnStatistik.Font=new Font("Bahnschrift Light", 12F, FontStyle.Regular, GraphicsUnit.Point);
            btnStatistik.ForeColor=Color.Black;
            btnStatistik.Location=new Point(20, 416);
            btnStatistik.Margin=new Padding(0, 0, 0, 20);
            btnStatistik.Name="btnStatistik";
            btnStatistik.Size=new Size(150, 35);
            btnStatistik.TabIndex=14;
            btnStatistik.Text="Statistik";
            btnStatistik.TextAlign=ContentAlignment.MiddleLeft;
            btnStatistik.UseVisualStyleBackColor=true;
            btnStatistik.Click+=btnStatistik_Click;
            // 
            // label17
            // 
            label17.AutoSize=true;
            label17.Font=new Font("Bahnschrift Light", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            label17.ForeColor=Color.Black;
            label17.Location=new Point(12, 14);
            label17.Name="label17";
            label17.Size=new Size(197, 41);
            label17.TabIndex=24;
            label17.Text="Välkommen";
            // 
            // Form1
            // 
            AutoScaleDimensions=new SizeF(8F, 20F);
            AutoScaleMode=AutoScaleMode.Font;
            BackColor=Color.White;
            ClientSize=new Size(1354, 705);
            Controls.Add(panel1);
            Controls.Add(tabControl1);
            Controls.Add(label17);
            Controls.Add(btnPersonalÄndra);
            Controls.Add(button7);
            Controls.Add(btnPersonalRegistrera);
            Controls.Add(btnStatistik);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnBeställningar);
            Controls.Add(btnKunder);
            Controls.Add(btnHattar);
            Controls.Add(btnMaterial);
            Controls.Add(btnStart);
            ForeColor=Color.White;
            FormBorderStyle=FormBorderStyle.FixedSingle;
            Icon=(Icon)resources.GetObject("$this.Icon");
            Name="Form1";
            StartPosition=FormStartPosition.CenterScreen;
            Text="Start";
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridStart).EndInit();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridBeställning).EndInit();
            tabPage3.ResumeLayout(false);
            tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridKund).EndInit();
            tabPage4.ResumeLayout(false);
            tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridHatt).EndInit();
            tabPage5.ResumeLayout(false);
            tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridDekoration).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridMaterial).EndInit();
            tabPage7.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private Button btnStart;
        private Button btnBeställningar;
        private Button btnKunder;
        private Button btnHattar;
        private Button btnMaterial;
        private Button button7;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private TabPage tabPage3;
        private TabPage tabPage4;
        private TabPage tabPage5;
        private DataGridView dataGridStart;
        private Button btnBeställningÄndra;
        private Button btnBeställningLäggtill;
        private DataGridView dataGridBeställning;
        private Button btnKundÄndra;
        private Button btnKundLäggtill;
        private DataGridView dataGridKund;
        private Button btnSökBeställning;
        private TextBox tbxSökBeställning;
        private Button btnKundSök;
        private TextBox tbxSökKund;
        private Button btnStartSkapa;
        private DataGridView dataGridHatt;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private DataGridView dataGridMaterial;
        private DataGridView dataGridDekoration;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private Button btnPersonalÄndra;
        private Button btnPersonalRegistrera;
        private Panel panel1;
        private Button btnÄndraHatt;
        private Button btnLäggTillHatt;
        private Label lblStartHeader;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private DataGridViewTextBoxColumn Column3;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column6;
        private DataGridViewTextBoxColumn Column5;
        private DataGridViewTextBoxColumn Orderstatus;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private DataGridViewTextBoxColumn Column4;
        private TabPage tabPage7;
        private Panel panel2;
        private Label label13;
        private Button btnSökStatistik;
        private DateTimePicker dtpToDate;
        private Label label15;
        private DateTimePicker dtpFromDate;
        private Label label14;
        private Button btnStatistik;
        private Label label16;
        private ComboBox cbbOrderStatus;
        private Label label17;
        private DataGridViewTextBoxColumn Datum;
    }
}