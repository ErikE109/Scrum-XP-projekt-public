﻿namespace DAL.Repositories
{
    public interface IRepository<T> where T : class
    {

        void Add(T entity);

        void Update(T entity);

        void Delete(T entity);

        void Save();

        IEnumerable<T> GetAll();

        T GetItem(int id);

    }
}
